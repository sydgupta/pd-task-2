import axios from 'axios';

const httpClient = axios.create({
    baseURL: 'http://localhost:4000/',
    timeout: 2000,
    headers: {
        'Content-Type': 'application/json'
    }
})

const NetwrokService = {
    getData: (url, responseType, queryParams) =>
        httpClient({
            method: "GET",
            url: url,
            params: queryParams,
            responseType: responseType
    })
}

export default NetwrokService;