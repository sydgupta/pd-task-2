export const appConstants = {
    appName: "PrimeDigital Task",
    baseURL: 'http://localhost:4000/'
}