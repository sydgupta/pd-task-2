export const appURLs = {
    getSearchDataUrl(type, filters, queryText) {
        if(type && filters && filters[type].length){
            let searchQuery = filters[type].join();
            if(queryText) {
                return `planets?q=${queryText}&${type}=${searchQuery}`;
            }
            if(filters[type].length > 1) {
                return `planets?filter=${searchQuery}`;
            }
            return `planets?${type}=${searchQuery}`;
        }
        if(queryText) {
            return `planets?q=${queryText}`;
        }
        return `planets`;
    },
    getShapeFilterDataUrl() {
        return 'shapes';
    },
    getColorFilterDataUrl() {
        return 'colors';
    },
    getSizeFilterDataUrl() {
        return 'sizes';
    }
}