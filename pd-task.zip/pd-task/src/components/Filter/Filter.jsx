import './Filter.scss';
import React from 'react';
import { getSearchData } from '../../redux/actions/search-actions';
import { connect, useSelector } from 'react-redux'
import Checkbox from '@material-ui/core/Checkbox';

const Filter = (props) => {

    const selectedFilters = {shape: [], color: [], size: []};
    const quertyString = useSelector(state => state.searchData?.queryString);
    const localData = JSON.parse(localStorage.getItem('planetSearch'));

    function handleChange(type, id, status) {
        if(status) {
            selectedFilters[type.toLowerCase()].push(id);
        }
        else{
            let deleteIdIndex = selectedFilters[type.toLowerCase()].indexOf(id);
            selectedFilters[type.toLowerCase()].splice(deleteIdIndex, 1);
        }
        props.getSearchData(type.toLowerCase(), selectedFilters, quertyString);
        if(localData) {
            localStorage.setItem('planetSearch', JSON.stringify({...localData, filters: selectedFilters}));
        }
        else {
            let filterData = {
                filters: selectedFilters,
            }
            localStorage.setItem('planetSearch', JSON.stringify(filterData));
        }
    }

    function returnFilterName(index) {
        if(index === 0) {
            return 'Shape';
        }
        else if(index === 1) {
            return 'Color';
        }
        else if(index === 2) {
            return 'Size';
        }
    }

    function isChecked(index, filter) {
        if(localData) {
            let filterName = (returnFilterName(index)).toLocaleLowerCase();
            // console.log(localData?.filters[filterName]);
            if(localData?.filters[filterName]) {
                let checkedStatus = localData?.filters[filterName]?.find(item => item === filter?.id);
                if(checkedStatus) {
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        }
        return false;
    }

    return (
        <div className="filters">
            {(props.filterData && props.filterData.length) && props.filterData.map((filter, index) => (
                <div className="filter-list" key={index}>
                    <h4>{returnFilterName(index)}</h4>
                    <ul>
                        {(filter?.data && filter.data.length) && filter.data.map((filterType) => (
                            <li key={filterType?.id}>
                                <Checkbox
                                    name={filterType?.name}
                                    color="primary"
                                    onChange={(e) => handleChange(returnFilterName(index), filterType?.id, e.target.checked)}
                                    defaultChecked={isChecked(index, filterType)}
                                />
                                <label>{filterType?.name}</label>
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>
    )
}

export default connect(null, {getSearchData})(Filter);
