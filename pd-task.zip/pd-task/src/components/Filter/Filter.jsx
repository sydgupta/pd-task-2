import './Filter.scss';
import React from 'react';
import { getSearchData } from '../../redux/actions/search-actions';
import { connect, useSelector } from 'react-redux'
import Checkbox from '@material-ui/core/Checkbox';

const Filter = (props) => {
    function returnFilterName(index) {
        if(index === 0) {
            return 'Shape';
        }
        else if(index === 1) {
            return 'Color';
        }
        else if(index === 2) {
            return 'Size';
        }
    }

    const selectedFilters = {shape: [], color: [], size: []};
    const quertyString = useSelector(state => state.searchData?.queryString);

    function handleChange(type, id, status) {
        if(status) {
            selectedFilters[type.toLowerCase()].push(id);
        }
        else{
            let deleteIdIndex = selectedFilters[type.toLowerCase()].indexOf(id);
            selectedFilters[type.toLowerCase()].splice(deleteIdIndex, 1);
        }
        props.getSearchData(type.toLowerCase(), selectedFilters, quertyString);

        let localData = localStorage.getItem('planetSearch');
        if(localData) {
            localStorage.setItem('planetSearch', JSON.stringify({...JSON.parse(localData), filters: selectedFilters}));
        }
        else {
            let filterData = {
                filters: selectedFilters,
            }
            localStorage.setItem('planetSearch', JSON.stringify(filterData));
        }
    }

    return (
        <div className="filters">
            {(props.filterData && props.filterData.length) && props.filterData.map((filter, index) => (
                <div className="filter-list" key={index}>
                    <h4>{returnFilterName(index)}</h4>
                    <ul>
                        {(filter?.data && filter.data.length) && filter.data.map((filterType) => (
                            <li key={filterType?.id}>
                                <Checkbox
                                    name={filterType?.name}
                                    color="primary"
                                    onChange={(e) => handleChange(returnFilterName(index), filterType?.id, e.target.checked)}
                                />
                                <label>{filterType?.name}</label>
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>
    )
}

export default connect(null, {getSearchData})(Filter);
