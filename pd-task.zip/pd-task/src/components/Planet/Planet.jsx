import {connect} from 'react-redux';

const nameStyle = {
    fontSize: '20px',
    marginTop: '20px'
}

const descStyle = {
    fontSize: '18px',
    marginTop: '10px',
    color: '#666'
}

const Planet = (props) => {

    let color = props.colors?.filter(item => item.id === props.data?.color);
    let shape = props.shapes?.filter(item => item.id === props.data?.shape);

    return (
        <div className="planet">
            <div className="name" style={nameStyle}>{props.data?.name}</div>
            <div className="desc" style={descStyle}>{`${props.data?.name} have ${color[0].name} color and ${shape[0].name} shape.`}</div>
        </div>
    )   
}

const mapStateToProps = (state) => {
    return {
        shapes: state.filterData.responseData.shapes,
        colors: state.filterData.responseData.colors
    }
}

export default connect(mapStateToProps)(Planet);