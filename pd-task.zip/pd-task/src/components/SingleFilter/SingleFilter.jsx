import Checkbox from '@material-ui/core/Checkbox';
import React from 'react';

const SingleFilter = (props) => {

    // const [localFilters, setLocalFilters] = useState({});
    // const [checkboxStatus, setCheckboxStatus] = useState(false);
    const localData = JSON.parse(localStorage.getItem('planetSearch'));
    let localFilters = {};

    if(localData && (localData?.filters?.shape?.length || localData?.filters?.size?.length || localData?.filters?.color?.length)){
        // setLocalFilters(localData.filters);
        localFilters = localData.localFilters;
    }

    function returnFilterName(index) {
        if(index === 0) {
            return 'Shape';
        }
        else if(index === 1) {
            return 'Color';
        }
        else if(index === 2) {
            return 'Size';
        }
    }

    let filterName = returnFilterName(props.index);
    filterName = filterName.toLocaleLowerCase();
    // console.log('Local Filter Data: ', localFilters);

    // localFilters[filterName]?.forEach(item => {
    //     if(item === props?.data?.id){
    //         setCheckboxStatus(true);
    //     }
    // })

    console.log('lllllllllllll: ', props.checkedItem)

    return (
        <li key={props.data?.id}>
            <Checkbox
                name={props.data?.name}
                color="primary"
                onChange={(e) => props.filterFunction(
                    returnFilterName(props.index), 
                    props.data?.id, 
                    e.target.checked
                )}
                checked={localFilters[filterName]?.filter(item => item === props?.data?.id)}
            />
            <label>{props.data?.name}</label>
        </li>
    )
}

// const mapStateToProps = (state) => {
//     return {

//     }
// }

export default SingleFilter;