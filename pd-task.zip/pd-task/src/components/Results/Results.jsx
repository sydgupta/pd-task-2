import './Results.scss';
import React from 'react';
import {useSelector} from 'react-redux';
import Planet from '../Planet/Planet';

const Results = () => {
    const searchData = useSelector(state => state.searchData.responseData);
    return (
        <div className="results-listing">
            <h4>Results</h4>
            {(searchData && searchData.length)? searchData.map((data) => (
                <Planet data={data} key={data?.id} />
            )) : 'No Planets Found'}
        </div>
    )
}

export default Results;