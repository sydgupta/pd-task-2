import './Search.scss';
import React from 'react';
import TextField from '@material-ui/core/TextField';
import { getSearchData, getShapesFilterData, getSizesFilterData, getColorsFilterData } from '../../redux/actions/search-actions';
import { connect, useSelector } from 'react-redux';

const SearchPanel = (props) => {
    let textInput = React.createRef();
    const query = useSelector(state => state.searchData?.queryString);
    function searchPlanet() {
        if(textInput.current.value){
            console.log(textInput.current.value);
            props.getSearchData(null, null, textInput.current.value);
            let localData = localStorage.getItem('planetSearch');
            if(localData) {
                localStorage.setItem('planetSearch', JSON.stringify({...JSON.parse(localData), queryString: textInput.current.value}));
            }
            else {
                let query = {
                    queryString: textInput.current.value
                }
                localStorage.setItem('planetSearch', JSON.stringify(query));
            }
        }
    }

    return (
        <div className="search-panel">
            <h2>Search Planets</h2>
            <TextField inputRef={textInput} label="Search Planets" defaultValue={query} variant="outlined" />
            <button className="search-btn" onClick={searchPlanet}>Search</button>
        </div>
    )
}

export default connect(null, {getSearchData, getShapesFilterData, getSizesFilterData, getColorsFilterData})(SearchPanel)