import React, {useEffect, useState} from 'react';
import './App.scss';
import SearchPanel from './components/Search/Search';
import Filter from './components/Filter/Filter';
import Results from './components/Results/Results';
import { getSearchData, getShapesFilterData, getSizesFilterData, getColorsFilterData, setQueryString } from './redux/actions/search-actions';
import { connect } from 'react-redux';

function App(props) {
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
      Promise.all([props.getShapesFilterData(), props.getColorsFilterData(), props.getSizesFilterData()]).then(results => {
          setFilterData(results);
      }).catch(error => {
          console.log('Combined API ERROR: ', error);
      })
      let localData = JSON.parse(localStorage.getItem('planetSearch'));
      console.log('Local Data: ', localData);
      if(localData?.queryString) {
        props.setQueryString(localData.queryString);
        props.getSearchData(null, null, localData.queryString);
      }
      else{
        props.getSearchData();
      } 
  }, []);

  return (
    <div className="main-container">
      <div className="search-container">
        <SearchPanel />
      </div>

      <div className="content-wrapper">
        <div className="filters-wrapper">
          <Filter filterData={filterData} />
        </div>

        <div className="results-wrapper">
          <Results />
        </div>
      </div>
    </div>
  );
}

export default connect(
  null, 
  {
    getSearchData,
    getShapesFilterData,
    getSizesFilterData,
    getColorsFilterData,
    setQueryString
  })
(App);