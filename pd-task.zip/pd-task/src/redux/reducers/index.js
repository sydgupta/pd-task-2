import {combineReducers} from 'redux';
import { filtersData } from './filters.reducer';
// import userReducer from './user';
import {searchData} from './search.reducer';

const rootReducer = combineReducers({
    // 'user': userReducer
    'searchData': searchData,
    'filterData': filtersData
})

export default rootReducer;