import constants from '../constants/redux-constants';

const initialState = {
    responseData: {
        shapes: null,
        sizes: null,
        colors: null
    },
    selectedFilters: {
        shapes: null,
        sizes: null,
        colors: null
    },
    status: null,
    loader: false,
    errorObj: {
        shapes: null,
        sizes: null,
        colors: null
    }
}

export function filtersData(state=initialState, action) {
    switch(action.type) {
        case constants.SHAPES_FILTER:
            console.log('Shapes Success Reducer Case', action);
            return {
                ...state,
                responseData: {...state.responseData, shapes: action.resData},
                status: action.status,
                loader: false
            }

        case constants.SHAPES_FILTER_ERROR:
            console.log('Shapes Failure Reducer Case')
            return {
                ...state,
                status: action.status,
                errorObj: {...state.errorObj, shapes: action.resData},
                loader: false
            }

        case constants.NO_SHAPES_FILTER:
            console.log('Shapes With No Results Reducer Case')
            return {
                ...state,
                responseData: {...state.responseData, colors: action.resData},
                status: action.status,
                loader: false
            }

        case constants.COLORS_FILTER:
            console.log('Colors Success Reducer Case', action);
            return {
                ...state,
                responseData: {...state.responseData, colors: action.resData},
                status: action.status,
                loader: false
            }

        case constants.COLORS_FILTER_ERROR:
            console.log('Colors Failure Reducer Case')
            return {
                ...state,
                status: action.status,
                errorObj: {...state.errorObj, shapes: action.resData},
                loader: false
            }

        case constants.NO_COLORS_FILTER:
            console.log('Colors With No Results Reducer Case')
            return {
                ...state,
                responseData: {...state.responseData, colors: action.resData},
                status: action.status,
                loader: false
            }

        case constants.SIZES_FILTER:
            console.log('Sizes Success Reducer Case', action);
            return {
                ...state,
                responseData: {...state.responseData, sizes: action.resData},
                status: action.status,
                loader: false
            }

        case constants.SIZES_FILTER_ERROR:
            console.log('Sizes Failure Reducer Case')
            return {
                ...state,
                status: action.status,
                errorObj: {...state.errorObj, sizes: action.resData},
                loader: false
            }

        case constants.NO_SIZES_FILTER:
            console.log('Sizes With No Results Reducer Case')
            return {
                ...state,
                responseData: {...state.responseData, sizes: action.resData},
                status: action.status,
                loader: false
            }

        case constants.SET_FILTERS:
            console.log('Selected Filters Reducer Case');
            return {
                ...state,
                selectedFilters: {...state.selectedFilters, ...action.payload},
            }

        default:
            return state;
    }
}