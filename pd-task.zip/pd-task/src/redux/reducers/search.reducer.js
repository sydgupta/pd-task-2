import constants from '../constants/redux-constants';

const initialState = {
    responseData: null,
    status: null,
    loader: false,
    errorObj: null,
    queryString: null
}

export function searchData(state=initialState, action) {
    switch(action.type) {
        case constants.SEARCH:
            console.log('Search Success Reducer Case');
            return {
                ...state,
                responseData: action.resData,
                status: action.status,
                loader: false,
                queryString: action?.queryString
            }

        case constants.SEARCH_ERROR:
            console.log('Search Failure Reducer Case')
            return {
                ...state,
                status: action.status,
                errorObj: action.resData,
                loader: false
            }

        case constants.SEARCH_NO_RESULTS:
            console.log('Search With No Results Reducer Case')
            return {
                ...state,
                responseData: action.resData,
                status: action.status,
                loader: false
            }
        
        case constants.SET_QUERY_STRING:
            console.log('Set Query String Reducer Case')
            return {
                ...state,
                state: action.status,
                queryString: action.queryString
            }

        default:
            return state;
    }
}