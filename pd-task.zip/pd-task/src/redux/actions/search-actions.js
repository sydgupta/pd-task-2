import constants from '../constants/redux-constants';
import NetworkService from '../../common/network-service';
import { appURLs } from '../../common/url-store';

export const getSearchData = (type, selectedFilters, queryText) => {
    return async (dispatch) => {
        try{
            let searchResults = await NetworkService.getData(appURLs.getSearchDataUrl(type, selectedFilters, queryText));
            if(searchResults.data && searchResults.data.length) {
                if(queryText) {
                    dispatch({type: constants.SEARCH, status: 'success', resData: searchResults.data, loader: false, queryString: queryText});
                }
                else{
                    dispatch({type: constants.SEARCH, status: 'success', resData: searchResults.data, loader: false});
                }
                // return searchResults;
            }
            else{
                dispatch({type: constants.SEARCH_NO_RESULTS, status: 'success', resData: searchResults.data, loader: false});
                // return searchResults;
            }
        }
        catch (error){
            console.log('Error in Get Results: ', error);
            dispatch({type: constants.SEARCH_ERROR, status: 'failure', resData: error, loader: false});
        }
    }
}

export const getShapesFilterData = () => {
    return async (dispatch) => {
        try{
            let filterShapes = await NetworkService.getData(appURLs.getShapeFilterDataUrl());
            if(filterShapes.data && filterShapes.data.length) {
                dispatch({type: constants.SHAPES_FILTER, status: 'success', resData: filterShapes.data, loader: false});
                return filterShapes;
            }
            else{
                dispatch({type: constants.NO_SHAPES_FILTER, status: 'success', resData: filterShapes.data, loader: false});
                return filterShapes;
            }
        }
        catch (error){
            console.log('Error in Getting Shapes: ', error);
            dispatch({type: constants.SHAPES_FILTER_ERROR, status: 'failure', resData: error, loader: false})
        }
    }
}

export const getColorsFilterData = () => {
    return async (dispatch) => {
        try{
            let filterColors = await NetworkService.getData(appURLs.getColorFilterDataUrl());
            if(filterColors.data && filterColors.data.length) {
                dispatch({type: constants.COLORS_FILTER, status: 'success', resData: filterColors.data, loader: false});
                return filterColors;
            }
            else{
                dispatch({type: constants.NO_COLORS_FILTER, status: 'success', resData: filterColors.data, loader: false});
                return filterColors;
            }
        }
        catch (error){
            console.log('Error in Getting COLORS: ', error);
            dispatch({type: constants.COLORS_FILTER_ERROR, status: 'failure', resData: error, loader: false})
        }
    }
}

export const getSizesFilterData = () => {
    return async (dispatch) => {
        try{
            let filterSizes = await NetworkService.getData(appURLs.getSizeFilterDataUrl());
            if(filterSizes.data && filterSizes.data.length) {
                dispatch({type: constants.SIZES_FILTER, status: 'success', resData: filterSizes.data, loader: false});
                return filterSizes;
            }
            else{
                dispatch({type: constants.NO_SIZES_FILTER, status: 'success', resData: filterSizes.data, loader: false});
                return filterSizes;
            }
        }
        catch (error){
            console.log('Error in Getting SIZES: ', error);
            dispatch({type: constants.SIZES_FILTER_ERROR, status: 'failure', resData: error, loader: false})
        }
    }
}

export const setQueryString = (queryString) => {
    return async (dispatch) => {
        dispatch({type: constants.SET_QUERY_STRING, status: 'success', queryString: queryString});
    }
}

export const setFilters = (filters) => {
    return async (dispatch) => {
        dispatch({type: constants.SET_FILTERS, status: 'success', payload: filters});
    }
}
